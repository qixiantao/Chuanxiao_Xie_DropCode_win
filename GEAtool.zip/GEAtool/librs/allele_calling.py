import os
import pandas as pd

# 定义目标字符串文件路径
target_file = "/mnt/d/GEAtool/input_file/index.fasta"

# 定义待检索文件目录
fastq_dir = "/mnt/d/GEAtool/input_file/"

# 读取目标字符串
try:
    with open(target_file, "r", encoding='ISO-8859-1') as f:
        lines = f.readlines()
    target_str = lines[1].strip()  # 去除目标字符串的换行符
except (FileNotFoundError, IndexError):
    print(f"Error: Target file {target_file} not found or format incorrect.")
    target_str = None

if target_str:
    # 遍历 fastq 文件
    fastq_files = os.listdir(fastq_dir)
    result_list = []
    for fastq_file in fastq_files:
        # 只处理 .fastq 文件
        if not fastq_file.endswith('.fastq'):
            continue
        
        # 检查是否是文件而不是目录
        filepath = os.path.join(fastq_dir, fastq_file)
        if not os.path.isfile(filepath):
            continue
        
        # 读取 fastq 文件前 5000 个数据单元
        try:
            with open(filepath, "r", encoding='ISO-8859-1') as f:
                lines = f.readlines()
                fastq_data = []
                for i in range(0, min(5000*4, len(lines)), 4):
                    data_unit = lines[i:i+4]
                    if len(data_unit) == 4:
                        fastq_data.append("".join(data_unit))
        except Exception as e:
            print(f"Error reading {fastq_file}: {e}")
            continue
        
        # 提取目标字符串后的 20 个字符
        target_strs = []
        for data in fastq_data:
            if target_str in data:
                start_idx = data.find(target_str)
                # 确保提取的字符串长度不超过原始字符串的长度
                extract_length = min(20, len(data) - start_idx - len(target_str))
                extracted = data[start_idx + len(target_str):start_idx + len(target_str) + extract_length]
                target_strs.append(extracted)
        
        # 统计序列占比
        unique_strs = set(target_strs)
        result = []
        for unique_str in unique_strs:
            count = target_strs.count(unique_str)
            # 防止分母为零
            if len(target_strs) == 0:
                percentage = 0
            else:
                percentage = count / len(target_strs) * 100
            result.append((unique_str, percentage))
        
        # 取前五占比序列
        result.sort(key=lambda x: x[1], reverse=True)
        top_five = result[:5]
        
        # 填充不足五项的序列，保持 DataFrame 格式一致
        top_five = top_five + [("", 0)] * (5 - len(top_five))
        
        # 将字符串转为 str 类型，避免 NoneType
        allele_results = []
        for tup in top_five:
            allele_str = f"{str(tup[0])}: {round(float(tup[1]), 2)}%"
            allele_results.append(allele_str)
        
        # 保存结果
        result_list.append([fastq_file, *allele_results])
    
    # 导出到 Excel 文件
    df = pd.DataFrame(result_list, columns=["Sample", "Allele1_Seq_Percent", "Allele2_Seq_Percent", 
                                            "Allele3_Seq_Percent", "Allele4_Seq_Percent", 
                                            "Allele5_Seq_Percent"])
    df.to_excel("/mnt/d/GEAtool/data/GEAnalysis_result.xlsx", index=False)
else:
    print("No target string found. Exiting.")