import openpyxl

# 设置 library.xlsx 文件路径
library_wb_path = "/mnt/d/GEAtool/librs/library.xlsx"

# 设置 barcode.xlsx 文件路径
barcode_wb_path = "/mnt/d/GEAtool/input_file/barcode.xlsx"

# 打开 library.xlsx 工作簿
library_wb = openpyxl.load_workbook(library_wb_path)

# 打开 barcode.xlsx 工作簿
barcode_wb = openpyxl.load_workbook(barcode_wb_path)

# 设置 library.xlsx 工作表
library_ws = library_wb["Sheet1"]

# 设置 barcode.xlsx 工作表
barcode_ws = barcode_wb["Sheet1"]

# 创建字典存储名称和密码
name_password_dict = {}

# 遍历 library.xlsx Sheet1 中的名称和密码，将它们添加到字典中
for i in range(2, library_ws.max_row + 1):  # 从第二行开始，假设第一行是标题行
    name = library_ws.cell(row=i, column=1).value
    password = library_ws.cell(row=i, column=2).value
    if name and password:
        name_password_dict[name] = password

# 遍历 barcode.xlsx Sheet1 中的所有单元格，查找 library.xlsx Sheet1 中的名称并替换为密码
for i in range(2, barcode_ws.max_row + 1):  # 从第二行开始，假设第一行是标题行
    for j in range(1, barcode_ws.max_column + 1):  # 从第一列开始到最后一列
        key = barcode_ws.cell(row=i, column=j).value
        if key and key in name_password_dict:
            barcode_ws.cell(row=i, column=j).value = name_password_dict[key]

# 保存并关闭工作簿
barcode_wb.save(barcode_wb_path)

print("barcode.xlsx Sheet1 中的名称已成功替换为密码！")