import openpyxl

# 设置工作簿和工作表
wb = openpyxl.load_workbook("/mnt/d/GEAtool/input_file/barcode.xlsx")
ws = wb["Sheet1"]

# 获取最后一行的行号
last_row = ws.max_row

# 设置 TXT 文件的路径和名称
file_path = "/mnt/d/GEAtool/input_file/barcode.txt"  # 将此路径替换为你的 TXT 文件路径和名称

# 打开文件准备写入
with open(file_path, "w") as f:
    # 写入第一行标题
    f.write("SampleName|index1|index2\n")  

    # 遍历每一行并写入 TXT 文件
    for i in range(2, last_row + 1):  # 假设第一行是标题行，从第二行开始
        sample_name = ws.cell(row=i, column=1).value  # 样品名
        index1 = ws.cell(row=i, column=2).value  # index1
        index2 = ws.cell(row=i, column=3).value  # index2

        # 构建每一行的字符串，格式为：样品名|index1|index2
        line = f"{sample_name}|{index1}|{index2}"

        # 写入 TXT 文件
        f.write(line + "\n")

# 显示消息，提示操作完成
print("密码集已成功导出到", file_path)