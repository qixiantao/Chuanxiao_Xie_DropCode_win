import os

def process_fasta(file_path):
    """处理fasta文件，将小写DNA序列转换为大写，如果已是大写则退出程序，并将修改后的序列写入新文件，并删除原始文件。

    Args:
        file_path: fasta文件路径
    """
    temp_file_path = file_path + "_uppercase"  # 临时文件路径

    with open(file_path, 'r') as f_in, open(temp_file_path, 'w') as f_out:
        for line in f_in:
            # 跳过注释行（以'>'开头）
            if line.startswith('>'):
                f_out.write(line)
                continue

            # 检查DNA序列是否全部是小写字母
            if line.strip().islower():
                # 将小写字母转换为大写
                new_line = line.upper()
                f_out.write(new_line)
            else:
                # 如果序列已经是大写，则退出程序
                print("序列已经是大写，退出程序！")
                return

    # 删除原始文件
    os.remove(file_path)

    # 重命名临时文件为原始文件名
    os.rename(temp_file_path, file_path)

# 文件路径
file_path = "/mnt/d/GEAtool/input_file/target.fasta"

# 处理fasta文件
process_fasta(file_path)