import os
import unicodedata

def replace_non_ascii(filepath):
    """将 fastq 文件中非 ASCII 字符替换为 ASCII 字符。

    Args:
        filepath: fastq 文件路径。
    """

    with open(filepath, "r") as f_in, open(filepath + "_ascii", "w") as f_out:
        for line in f_in:
            new_line = ''.join([
                char if unicodedata.category(char) in ["Cc", "Cf", "Cs", "Co", "Cn"] else chr(ord(char))
                for char in line
            ])
            f_out.write(new_line)

    # 删除原始文件
    os.remove(filepath)
    # 重命名临时文件为原始文件名
    os.rename(filepath + "_ascii", filepath)


# fastq 文件路径
fastq_dir = "/mnt/d/GEAtool/input_file/"

# 遍历目录下的所有 fastq 文件
for filename in os.listdir(fastq_dir):
    if filename.endswith(".fastq"):
        filepath = os.path.join(fastq_dir, filename)
        replace_non_ascii(filepath)

print("所有 fastq 文件已处理完毕！")