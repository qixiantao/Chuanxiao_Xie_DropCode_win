#!/bin/bash

# 获取 /mnt/d/GEAtool/raw_data/ 路径下的所有文件夹
for folder in /mnt/d/GEAtool/raw_data/*; do
  # 检查当前路径是否为文件夹
  if [ -d "$folder" ]; then
    # 获取文件夹名称
    folder_name=$(basename "$folder")

    # 将数据复制到 /mnt/d/GEAtool/input_file/
    cp "$folder"/* /mnt/d/GEAtool/input_file/

    # 运行 GEAtool.sh
    /mnt/d/GEAtool/librs/GEAtool.sh

    # 删除 reference.fasta 文件
    #rm "$folder"/reference.fasta

    # 将数据复制回原文件夹
    rsync -av /mnt/d/GEAtool/data/ "$folder"

    # 输出处理信息
    echo "已完成文件夹 $folder_name 的处理"
  fi
done