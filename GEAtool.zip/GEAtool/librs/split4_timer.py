import os  
from Bio import SeqIO  
from itertools import islice
import time  
  
# 创建存储拆分文件的文件夹  
output_folder = '/mnt/d/GEAtool/input_file'  
os.makedirs(output_folder, exist_ok=True)  
  
# 读取barcode.txt文件，创建一个字典，键为samplename，值为(index1, index2)  
barcode_dict = {}  
with open('/mnt/d/GEAtool/input_file/barcode.txt', 'r') as barcode_file:  
    for line in barcode_file:  
        samplename, index1, index2 = line.strip().split('|')  
        barcode_dict[samplename] = (index1, index2)  
  
# 定义批处理大小（每次处理500000个记录）  
BATCH_SIZE = 500000  
  
# 读取正向和反向测序文件  
forward_iterator = SeqIO.parse('/mnt/d/GEAtool/input_file/1.fastq', 'fastq')  
reverse_iterator = SeqIO.parse('/mnt/d/GEAtool/input_file/2.fastq', 'fastq')  
  
# 用于跟踪当前处理的记录数（可选）  
processed_count = 0  
  
# 批处理函数  
def process_batch(records_forward, records_reverse, barcode_dict, output_folder):  
    for record_forward, record_reverse in zip(records_forward, records_reverse):  
        forward_index = str(record_forward.seq[:10])  # 假设索引是序列的前10个字符  
        reverse_index = str(record_reverse.seq[:10])  # 假设索引是序列的前10个字符  
  
        for samplename, (index1, index2) in barcode_dict.items():  
            if forward_index == index1 and reverse_index == index2:  
                # 创建或打开输出文件  
                forward_output_file = os.path.join(output_folder, f'{samplename}_1.fastq')  
                reverse_output_file = os.path.join(output_folder, f'{samplename}_2.fastq')  
  
                # 写入记录  
                with open(forward_output_file, 'a') as output_forward:  
                    SeqIO.write(record_forward, output_forward, 'fastq')  
                with open(reverse_output_file, 'a') as output_reverse:  
                    SeqIO.write(record_reverse, output_reverse, 'fastq')  
                break  # 找到匹配的样本后，跳出内部循环  
  
# 批处理读取和写入  
while True:  
    forward_batch = list(islice(forward_iterator, BATCH_SIZE))  
    reverse_batch = list(islice(reverse_iterator, BATCH_SIZE))  
  
    # 如果任一文件已处理完，则退出循环  
    if not forward_batch or not reverse_batch:  
        break  
  
    process_batch(forward_batch, reverse_batch, barcode_dict, output_folder)  
    processed_count += len(forward_batch)  # 更新已处理的记录数  
  
 # 输出进度（timer的选项）
    current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) 
    print(f"Processed {processed_count} records at {current_time}.")