#!/bin/bash  

cd
sudo apt-get update
sudo apt-get install -y build-essential git wget
git clone https://github.com/OpenGene/fastp.git
cd fastp
Make
cd
apt install fastp
apt install python2
#会有选择，点击Y
apt install python3-pip
#会有选择，点击Y
pip install openpyxl
apt install bwa
apt install samtools
#会有选择，点击Y
pip3 install biopython