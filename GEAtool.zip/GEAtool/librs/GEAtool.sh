#!/bin/bash  
  
# 检查reference.fasta文件是否存在  
REFERENCE="/mnt/d/GEAtool/input_file/reference.fasta"  
  
if [ -f "$REFERENCE" ]; then  
    echo "reference.fasta文件输入正确"  
else  
    # 使用 read 命令读取用户输入，并输出错误信息  
    read -p "reference.fasta文件不存在，请将正确的reference.fasta 文件复制到Input文件夹内，再重新分析！ <1.确保为fasta格式；2.确保文件的正确命名；3.确保文件后缀为fasta> 按任意键退出……"  
    exit 1 # 退出脚本  
fi  
echo "Continue……"  
  
# 检查正向测序文件是否存在  
FASTQ_DIR="/mnt/d/GEAtool/input_file"  
  
# 使用 find 命令查找匹配的文件  
find "$FASTQ_DIR"/*1.fq.gz -print -quit  
  
# 检查 find 命令的退出状态  
if [ $? -eq 0 ]; then  
    echo "正向测序文件输入正确"  
else  
    read -p "正向测序文件不存在，请将测序文件的.1.fq.gz文件复制到Input文件夹内，再重新分析！按任意键退出……"  
    exit 1  # 退出脚本并返回状态码1  
fi  
echo "Continue……"  
  
# 使用 find 命令查找匹配的文件  
find "$FASTQ_DIR"/*2.fq.gz -print -quit  
  
# 检查 find 命令的退出状态  
if [ $? -eq 0 ]; then  
    echo "反向测序文件输入正确"  
else  
    read -p "反向测序文件不存在，请将测序文件的.2.fq.gz文件复制到Input文件夹内，再重新分析！按任意键退出……"  
    exit 1  # 退出脚本并返回状态码1  
fi  
echo "Continue……"

# 检测barcode.xlsx文件是否存在

BARCODE="/mnt/d/GEAtool/input_file/barcode.xlsx"  
  
if [ -f "$BARCODE" ]; then  
    echo "barcode.xlsx文件输入正确"  
else  
     read -p  "barcode.xlsx文件不存在，请将barcode.xlsx文件复制到Input文件夹内，再重新分析！按任意键退出……"  
    exit 1  # 退出脚本并返回状态码1  
fi    
echo "Continue……"

# 检测target.fasta文件是否存在
#TARGET="/mnt/d/GEAtool/input_file/target.fasta"  
  
#if [ -f "$TARGET" ]; then  
#    echo "正向测序文件输入正确"  
#else  
 #    read -p  "target.fasta文件不存在，请将target.fasta文件复制到Input文件夹内，再重新分析！ <1.确保为fasta格式；2.确保文件的正确命名；3.确保文件后缀为fasta>"  
  #  exit 1  # 退出脚本并返回状态码1  
#fi    
#echo "Continue……"

#barcode生成
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/barcode1.py
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/barcode2.py
echo "barcode阅读已完成!"

#参考序列及target序列检查
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/refer_upper.py
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/target_upper.py
echo "序列检测完成!"

#index文件建立
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/index.py
echo "正在执行数据Q30过滤"
rm -rf /mnt/d/GEAtool/data/*

#Q30文件过滤
 /mnt/d/GEAtool/librs/fastp_q30.sh
echo "数据准确率为99.9%"
echo "正在执行样品拆分工作（该步骤根据数据量大小决定运行时长，请耐心等待！！！）"

#子文库拆分
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/split4_timer.py
rm /mnt/d/GEAtool/input_file/1.fastq
rm /mnt/d/GEAtool/input_file/2.fastq
echo "样品拆分完成！！！"

#BAM文件创建
/mnt/d/GEAtool/librs/EG_BAM.sh

#BAM头部文件替换
/mnt/d/GEAtool/librs/RG.sh

#FASTQ子文库ASCII检查
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/ASCII.py

#突变统计总表输出
/home/qixiantao/miniconda3/bin/python /mnt/d/GEAtool/librs/allele_calling.py
cp /mnt/d/GEAtool/input_file/reference.fasta /mnt/d/GEAtool/data/BAM
cp ~/fastp.html /mnt/d/GEAtool/data/BAM

#清理input文件夹
rm -rf /mnt/d/GEAtool/input_file/*

#分析结束
echo "分析结束，请将data文件夹内数据尽快分析！！！！下一次分析数据data文件夹会被自动清理！！！！！"
