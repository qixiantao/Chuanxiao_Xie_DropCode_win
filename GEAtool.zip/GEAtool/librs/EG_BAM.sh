#!/bin/bash  
  
# 定义输入和输出路径  
INPUT_DIR="/mnt/d/GEAtool/input_file"  
REFERENCE="/mnt/d/GEAtool/input_file/reference.fasta"  
OUTPUT_DIR="/mnt/d/GEAtool/data/BAM"  

# 检查BAM文件夹是否存在，如果不存在则创建  
if [ ! -d "$OUTPUT_DIR" ]; then  
    mkdir -p "$OUTPUT_DIR"  
    echo "BAM文件夹已创建在 $OUTPUT_DIR"  
fi  

# 建立参考序列引索文件（注意：通常索引只需要建立一次，除非参考文件有变动）  
bwa index "$REFERENCE"  
  
# 遍历输入目录下的所有文件  
for file in "$INPUT_DIR"/*_1.fastq; do  
  # 获取文件名  
  SAMPLE_NAME=$(basename "$file" _1.fastq)  
  
  # BWA比对  
  bwa mem -t 10 -k 15 -M "$REFERENCE" "$file" "${INPUT_DIR}/${SAMPLE_NAME}_2.fastq" > "${OUTPUT_DIR}/${SAMPLE_NAME}.sam" 
  
  # 将SAM转换为BAM格式  
  samtools view -b -f 2  -F 4 -F 256 -F 2048 -q 20  "${OUTPUT_DIR}/${SAMPLE_NAME}.sam" > "${OUTPUT_DIR}/${SAMPLE_NAME}.bam"  
  
  # 排序BAM文件  
  samtools sort -m 1G "${OUTPUT_DIR}/${SAMPLE_NAME}.bam" -o "${OUTPUT_DIR}/${SAMPLE_NAME}.sorted.bam"  
  
  # 删除中间文件  
  rm "${OUTPUT_DIR}/${SAMPLE_NAME}.sam"  
  rm "${OUTPUT_DIR}/${SAMPLE_NAME}.bam"  
  
  # 注意：复制参考序列到BAM文件夹可能不是必要的，除非有特别的原因  
cp "$REFERENCE" "$OUTPUT_DIR/"  # 如果确实需要，可以取消这行的注释  
  
  echo "已完成 $SAMPLE_NAME 的比对、排序"  
done  
  
echo "所有样本的处理已完成!"