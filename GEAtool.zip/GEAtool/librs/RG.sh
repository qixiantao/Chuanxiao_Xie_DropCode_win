#!/bin/bash  

# 设置Picard工具的路径（如果不在PATH中）  
PICARD_JAR=/home/qixiantao/picard.jar  

# 设置BAM文件所在的目录  
BAM_DIR="/mnt/d/GEAtool/data/BAM"  

# 设置参考基因组文件路径
REFERENCE_FASTA="/mnt/d/GEAtool/input_file/reference.fasta"

# 遍历BAM目录下的所有bam文件  
for bam in "$BAM_DIR"/*.bam; do  
    # 提取文件名（不包括路径）  
    filename=$(basename "$bam")  
    # 去掉.bam后缀得到前缀  
    prefix="${filename%.*}"  

    # 设置新的BAM文件名（添加_new后缀以避免覆盖原始文件）  
    new_bam="${BAM_DIR}/${prefix}_new.bam"  

    # 使用Picard添加@RG标签（根据你的需求设置ID, LB, PL, PU, SM）  
    java -jar "$PICARD_JAR" AddOrReplaceReadGroups I="$bam" O="$new_bam" RGID="${prefix}_rg" RGLB=library1 RGPL=T7 RGPU=unit1 RGSM="${prefix}_rg"  

    # 检查命令是否成功执行（根据Picard的退出码）  
    if [ $? -eq 0 ]; then  
        # 如果成功，则删除原始BAM文件  
        rm "$bam"  
        # 并将新的BAM文件名重命名为原始BAM文件的名称  
        mv "$new_bam" "$bam"  

        # 建立索引，使用samtools index
        samtools index -b "$bam" "$bam".bai
        samtools faidx /mnt/d/GEAtool/data/BAM/reference.fasta

    else  
        echo "Error adding @RG to $bam"  
    fi  
done  

echo "Done processing BAM files in $BAM_DIR"