from Bio import SeqIO
from Bio.Seq import Seq

def extract_upstream_sequence(target_fasta, reference_fasta, output_fasta, upstream_length=10):
    """
    在参考序列中查找目标序列并提取其5'端上游序列或3'端下游序列，
    并根据目标序列在参考序列中的位置进行反向互补处理。

    参数：
        target_fasta: 目标序列的fasta文件路径。
        reference_fasta: 参考序列的fasta文件路径。
        output_fasta: 输出上游序列或下游序列的fasta文件路径。
        upstream_length: 上游序列或下游序列长度（以碱基数为单位）。

    返回：
        无
    """

    # 读取目标序列和参考序列
    with open(target_fasta, "r") as target_file:
        target_seq = next(SeqIO.parse(target_file, "fasta")).seq

    with open(reference_fasta, "r") as reference_file:
        reference_seq = next(SeqIO.parse(reference_file, "fasta")).seq

    # 查找目标序列在参考序列中的位置
    try:
        start_index = reference_seq.find(target_seq)
    except ValueError:
        print(f"目标序列 '{target_seq}' 未找到在参考序列中。")
        return

    # 判断目标序列位置
    reference_length = len(reference_seq)
    if start_index < reference_length // 2:
        # 目标序列位于参考序列前半部分，直接提取上游序列
        end_index = start_index - upstream_length
        if end_index < 0:
            print(f"上游序列超出参考序列范围。")
            return
        upstream_seq = reference_seq[end_index:start_index]
    else:
        # 目标序列位于参考序列后半部分，提取下游序列并进行反向互补
        end_index = start_index + len(target_seq) + upstream_length  # 修正下游序列的起始位置
        if end_index > reference_length:
            print(f"下游序列超出参考序列范围。")
            return
        upstream_seq = reference_seq[end_index - upstream_length:end_index]  # 修正下游序列的结束位置
        upstream_seq = upstream_seq.reverse_complement()

    # 创建新的fasta文件并写入上游序列
    with open(output_fasta, "w") as output_file:
        output_file.write(f">upstream_seq\n{upstream_seq}\n")

# 运行程序
extract_upstream_sequence(
    target_fasta="/mnt/d/GEAtool/input_file/target.fasta",
    reference_fasta="/mnt/d/GEAtool/input_file/reference.fasta",
    output_fasta="/mnt/d/GEAtool/input_file/index.fasta",
    upstream_length=10
)