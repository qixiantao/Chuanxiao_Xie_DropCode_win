@echo off  
setlocal  
  
:: 获取Windows用户名  
set "windows_username=%USERNAME%"  
  
:: 启动 setup.lnk  
start "" "D:\GEAtool\librs\WSLSET.lnk"  
if %errorlevel% equ 0 (  
    echo Setup.lnk 已启动  
) else (  
    echo 无法启动 setup.lnk  
    goto EndScript  
)  
  
:: 执行文件复制操作  
copy D:\GEAtool\GEAtool.lnk C:\Users\%windows_username%\Desktop\  
if %errorlevel% equ 0 (  
    echo 文件已复制到桌面  
) else (  
    echo 无法复制文件到桌面  
)  
  
:EndScript  
endlocal