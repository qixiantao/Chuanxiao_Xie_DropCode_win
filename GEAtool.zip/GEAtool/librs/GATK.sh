#!/bin/bash  
  
# 设置GATK的路径（如果GATK不在PATH中）  
GATK_PATH="/home/qixiantao/gatk/gatk"  # 替换为你的GATK路径  
  
# 设置参考序列和字典文件的路径  
REFERENCE="/mnt/d/GEAtool/data/BAM/reference.fasta"  
DICT="/mnt/d/GEAtool/data/BAM/reference.dict"  
  
# 确保字典文件存在，如果不存在则创建  
if [ ! -f "$DICT" ]; then  
    "$GATK_PATH" CreateSequenceDictionary -R "$REFERENCE" -O "$DICT"  
    if [ $? -ne 0 ]; then  
        echo "Error creating sequence dictionary"  
        exit 1  
    fi  
fi  
  
# 设置BAM文件和VCF文件的输入输出目录  
BAM_DIR="/mnt/d/GEAtool/data/BAM"  
VCF_DIR="/mnt/d/GEAtool/data/VCF"  
  
# 确保VCF目录存在  
mkdir -p "$VCF_DIR"  
  
# 遍历BAM目录下的所有BAM文件  
for bam in "$BAM_DIR"/*.bam; do  
    # 提取BAM文件名（不包括路径和后缀）  
    sample_name=$(basename -- "$bam" .bam)  
      
    # 设置输出VCF文件的路径  
    vcf_file="$VCF_DIR/$sample_name.g.vcf"  
      
    # 使用GATK 4的HaplotypeCaller进行SNP calling  
    # 注意：GATK 4的参数可能与GATK 3不同  
    "$GATK_PATH" HaplotypeCaller --reference "$REFERENCE" --input "$bam" -L 1:80-100 --output "$vcf_file" --read-filter MappingQualityReadFilter --min-base-quality-score 20 --annotation MappingQualityRankSumTest --annotation DepthPerSampleHC --annotation ClippingRankSumTest --annotation BaseQualityRankSumTest --ploidy 1 --interval-set-rule UNION --interval-merging-rule OVERLAPPING_ONLY  
  
    # 检查命令是否成功执行  
    if [ $? -eq 0 ]; then  
        echo "SNP calling completed for $sample_name"  
    else  
        echo "Error during SNP calling for $sample_name"  
    fi  
done  
  
echo "SNP calling completed for all BAM files in $BAM_DIR"