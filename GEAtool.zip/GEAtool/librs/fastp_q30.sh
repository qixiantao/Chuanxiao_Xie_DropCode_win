#!/bin/bash  
  
# 设定目录路径  
dir="/mnt/d/GEAtool/input_file"  
    html_report="/mnt/d/GEAtool/data/fastp_report.html"
    json_report="/mnt/d/GEAtool/data/fastp_report.json"
  
# 遍历目录中的文件  
for gz_file in "$dir"/*1.fq.gz; do  
    # 提取文件名（不包括路径和后缀）  
    base_name=$(basename -- "$gz_file" .fq.gz)  
    prefix="${base_name%1}"  
      
    # 正向测序文件解压  
    gunzip -c "$gz_file" > "$dir/${prefix}1.fq"  
      
    # 检查反向测序文件是否存在  
    if [[ -f "$dir/${prefix}2.fq.gz" ]]; then  
        # 反向测序文件解压  
        gunzip -c "$dir/${prefix}2.fq.gz" > "$dir/${prefix}2.fq"  
          
        # 运行fastp命令  
        fastp -i "$dir/${prefix}1.fq" -I "$dir/${prefix}2.fq" -o /mnt/d/GEAtool/input_file/1.fastq -O /mnt/d/GEAtool/input_file/2.fastq -q 30 -l 70 -h /mnt/d/GEAtool/data/${prefix}_fastp_report.html -j /mnt/d/GEAtool/data/${prefix}_fastp_report.json  
          
        # 如果不需要保留原始解压后的文件，可以删除它们  
     rm -f "$dir/${prefix}1.fq"  
     rm -f "$dir/${prefix}2.fq"  
   else  
       echo "Reverse read file $dir/${prefix}2.fq.gz not found!"  
    fi  
      
    # 删除原始.gz文件（如果您确定不再需要它）  
    rm -f "$gz_file"  
    rm -f "$dir/${prefix}2.fq.gz"  
   done  
  
# 注意：这个脚本会覆盖/mnt/d/1.fastq和/mnt/d/2.fastq，如果您想要为每个样本保留不同的输出文件，请修改输出文件路径