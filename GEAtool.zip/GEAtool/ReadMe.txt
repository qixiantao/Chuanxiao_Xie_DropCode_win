                                                                                            *****English Version*****

1.Installation Instructions:
1).Double-click the "Setup" button to initiate automatic installation.
2)During the installation process, you will be prompted three times whether to continue. Please enter "Y" and press Enter each time.
3)Upon completion, a desktop shortcut will be created.

2.Software Usage Instructions:
>Single-Task Analysis:
1).Place reference.fasta, positive and negative files from next-generation sequencing, and the barcode file into a folder, then import this folder into the "<Data Input/Output>" directory.
2).Click on the GEAtool shortcut to initiate the analysis.
3).The analysis results will be saved within the "<Data Input/Output>" folder.
>Multi-Task Analysis:
1).Organize different sets of reference.fasta, positive and negative files from next-generation sequencing, and barcode files into separate, named folders. 2).Then, import all these folders into the "<Data Input/Output>" directory.
3).Click on the GEAtool shortcut to initiate the analysis.
4).The analysis results for each set will be saved within their respective subfolders within the "<Data Input/Output>" folder.

 

                                                                                            *****中文说明书*****

一、安装说明：
1.双击Setup按钮进行自动安装
2.安装过程中会有三次提示是否继续安装，请分别输入Y并回车
3.安装完成后会生成桌面快捷方式

二、软件使用说明：
>单任务分析：
1.将reference.fasta、二代测序正反文件、barcode文件放入文件夹内，并将文件夹导入到<数据输入输出>文件夹内；
2.点击GEAtool快捷方式进行分析；
3.分析数据保存在<数据输入输出>文件夹内。
>多任务分析：
1.分别将将不同组的reference.fasta、二代测序正反文件、barcode文件放入不同命名文件夹，之后将所有文件夹导入到<数据输入输出>文件夹内；
2.点击GEAtool快捷方式进行分析；
3.分析数据保存在<数据输入输出>文件夹的各自子文件夹内。

